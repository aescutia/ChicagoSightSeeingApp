/*
* CS 378 Project 1: Sightseeing App
* By: Alexis Escutia
* NetID: aescut3
* UIN: 679743479
* SleepWidgets.dart - Sets up the screens
* for all the icons associated w/
* the SLEEP Tab
*/

import 'package:flutter/material.dart';

// Global Vars that store the # of likes for
// each hotel icon
int _h1Likes = 0;
int _h2Likes = 0;
int _h3Likes = 0;

class ScreenFive extends StatefulWidget {
  const ScreenFive({Key? key}) : super(key: key);
  @override
  State<ScreenFive> createState() => _FifthScreen();
}

// Screen for Hotel 1 Icon
class _FifthScreen extends State<ScreenFive> {
  void _incrementLikes() {
    setState(() {
      _h1Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('London House Chicago',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image4',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: const Color.fromARGB(0xFF,0x81,0xD4,0xFA), width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/LondonHouseChi.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.lightBlueAccent,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 85 E Wacker Dr, Chicago, IL 60601\n\n'
                'if you\'re looking to spend the night downtown\n'
                'then consider staying at the London House!\n'
                'This hotel is right in the heart of downtown\n'
                'and is only a short walk away from many\n'
                'of Chicago\'s attractions. The hotel also has\n'
                'a nice view of the city and is right on the edge\n'
                'of the Chicago River. Prices start at around\n'
                '\$130 a night, taxes and fees not included.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('London House Chicago has been liked $_h1Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Icon(Icons.favorite_border_sharp),
        backgroundColor: const Color.fromARGB(0xFF,0x81,0xD4,0xFA),
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}

class ScreenSix extends StatefulWidget {
  const ScreenSix({Key? key}) : super(key: key);
  @override
  State<ScreenSix> createState() => _SixthScreen();
}

// Screen for Hotel 2 Icon
class _SixthScreen extends State<ScreenSix> {
  void _incrementLikes() {
    setState(() {
      _h2Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('The Drake',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image5',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                    },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: const Color.fromARGB(0xFF,0x81,0xD4,0xFA), width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/TheDrake.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.lightBlueAccent,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 140 E Walton Pl, Chicago, IL 60611\n\n'
                'If you\'re looking for a hotel with a nice view \n'
                'of Lake Michigan, then look no further than\n'
                'The Drake Hotel! The Drake is located on the\n'
                'corner of Michigan Ave and Lake Shore Drive.\n'
                'It is a block away from Oak Street Beach\n'
                'and is at the end of Chicago\'s Magnificent Mile.\n'
                'Prices start at around \$125 a night, taxes and\n'
                'fees not included.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('The Drake has been liked $_h2Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Icon(Icons.favorite_border_sharp),
        backgroundColor: const Color.fromARGB(0xFF,0x81,0xD4,0xFA),
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}

class ScreenSeven extends StatefulWidget {
  const ScreenSeven({Key? key}) : super(key: key);
  @override
  State<ScreenSeven> createState() => _SeventhScreen();
}

// Screen for Hotel 3 Icon
class _SeventhScreen extends State<ScreenSeven> {
  void _incrementLikes() {
    setState(() {
      _h3Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Intercontinental',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image6',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                    },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: const Color.fromARGB(0xFF,0x81,0xD4,0xFA), width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/Intercontinental.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.lightBlueAccent,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 505 Michigan Ave, Chicago, IL 60611\n\n'
                'If you\'re looking to spend a night in Chicago\'s\n'
                'Magnificent Mile, then Intercontinental Hotel\n'
                'is the place for you! Intercontinental can be\n'
                'found right next to the Tribune tower. This\n'
                'hotel also has a nice view of the city and\n'
                'is also close to the Chicago River. Prices\n'
                'start at around \$140 a night, taxes and\n'
                'fees not included.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('Intercontinental has been liked $_h3Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Icon(Icons.favorite_border_sharp),
        backgroundColor: const Color.fromARGB(0xFF,0x81,0xD4,0xFA),
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}