/*
* CS 378 Project 1: Sightseeing App
* By: Alexis Escutia
* NetID: aescut3
* UIN: 679743479
* main.dart - Sets up the App and the
* Home Screen of the app
*/

import 'package:flutter/material.dart';
import 'SleepWidgets.dart';
import 'SeeWidgets.dart';
import 'EatWidgets.dart';

void main () {
  runApp(
      MaterialApp(
        title: 'Chicago Sightseeing App',
        initialRoute: '/',
        routes: {
          '/':(context) => const DefaultTabController(length: 3, child: FirstScreen()),
          '/second': (context) => const ScreenTwo(),
          '/third': (context) => const ScreenThree(),
          '/fourth': (context) => const ScreenFour(),
          '/fifth': (context) => const ScreenFive(),
          '/sixth': (context) => const ScreenSix(),
          '/seventh': (context) => const ScreenSeven(),
          '/eighth': (context) => const ScreenEight(),
          '/ninth': (context) => const ScreenNine(),
          '/tenth': (context) => const ScreenTen(),
        },
      )
  );
}

// Home Screen of the App
class FirstScreen extends StatelessWidget {
  const FirstScreen({Key? key}) : super(key:key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Welcome to Chicago!',
          style: TextStyle(
            color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
            fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(image: AssetImage('Images/ChiSky.jpg'),
              fit: BoxFit.fill),
            borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
        bottom: const TabBar(
            tabs: <Widget>[
              Tab(
                icon: Text('EAT',
                  style: TextStyle(
                      color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                      fontSize: 20.0
                  ),
                ),
              ),
              Tab(
                icon: Text('SLEEP',
                  style: TextStyle(
                      color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                      fontSize: 20.0
                  ),
                ),
              ),
              Tab(
                icon: Text('SEE',
                  style: TextStyle(
                      color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                      fontSize: 20.0
                  ),
                ),
              ),
            ],
        ),
        toolbarHeight: 100,
      ),
      body:
          TabBarView(children: <Widget>[
            // First Tab Bar View
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/second');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: const Color.fromARGB(0xFF,0xE5,0x39,0x35), width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/ChiOven.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.redAccent,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Chicago Pizza and Oven\n            Grinder Co',
                        style: TextStyle(
                          color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                          fontSize: 15.0,
                        ),
                    ),
                  ],
                ),
                const Padding(padding: EdgeInsets.all(25.0)),
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image2',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/third');
                            },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: const Color.fromARGB(0xFF,0xE5,0x39,0x35), width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/FronteraGrill.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.redAccent,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Frontera Grill',
                      style: TextStyle(
                        color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                        fontSize: 15.0,
                      ),
                    ),
                  ],
                ),
                const Padding(padding: EdgeInsets.all(25.0)),
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image3',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/fourth');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: const Color.fromARGB(0xFF,0xE5,0x39,0x35), width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/KumasCorner.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.redAccent,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Kuma\'s Corner',
                      style: TextStyle(
                        color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                        fontSize: 15.0,),
                    ),
                  ],
                ),
              ],
            ),
            // Second Tab Bar View
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image4',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/fifth');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: const Color.fromARGB(0xFF,0x81,0xD4,0xFA), width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/LondonHouseChi.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.lightBlueAccent,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('London House Chicago',
                      style: TextStyle(
                          color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                          fontSize: 15.0
                      ),
                    ),
                  ],
                ),
                const Padding(padding: EdgeInsets.all(25.0)),
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image5',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/sixth');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color:  const Color.fromARGB(0xFF,0x81,0xD4,0xFA), width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/TheDrake.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.lightBlueAccent,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('The Drake',
                      style: TextStyle(
                        color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                        fontSize: 15.0,
                      ),
                    ),
                  ],
                ),
                const Padding(padding: EdgeInsets.all(25.0)),
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image6',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/seventh');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color:  const Color.fromARGB(0xFF,0x81,0xD4,0xFA), width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/Intercontinental.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.lightBlueAccent,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Intercontinental',
                      style: TextStyle(
                        color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                        fontSize: 15.0,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            // Third Tab Bar View
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image7',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/eighth');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.white, width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/ChiSkyDeck.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.white70,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Chicago Sky Deck',
                        style: TextStyle(
                          color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                          fontSize: 15.0,
                        ),
                    ),
                  ],
                ),
                const Padding(padding: EdgeInsets.all(25.0)),
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image8',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/ninth');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.white, width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/CloudGate.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.white70,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Cloud Gate',
                        style: TextStyle(
                          color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                          fontSize: 15.0,
                        ),
                    ),
                  ],
                ),
                const Padding(padding: EdgeInsets.all(25.0)),
                Row(
                  children: <Widget>[
                    const Padding(padding: EdgeInsets.all(20.0)),
                    Hero(
                      tag: 'image9',
                      child: Container(
                        width: 150,
                        height: 150,
                        child: GestureDetector(
                          onTap: (){
                            Navigator.pushNamed(context, '/tenth');
                          },
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.white, width: 5
                          ),
                          image: const DecorationImage(image: AssetImage('Images/NavyPier.jpeg')),
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.white70,
                                offset: Offset(1.0, 1.0),
                                blurRadius: 2.0,
                                spreadRadius: 5.0
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Padding(padding: EdgeInsets.all(10.0)),
                    const Text('Navy Pier',
                      style: TextStyle(
                        color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                        fontSize: 15.0,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
          ),
      backgroundColor: Colors.grey[900],
    );
  }
}
