/*
* CS 378 Project 1: Sightseeing App
* By: Alexis Escutia
* NetID: aescut3
* UIN: 679743479
* SeeWidgets.dart - Sets up the screens
* for all the icons associated w/
* the SEE Tab
*/

import 'package:flutter/material.dart';

// Global Vars that store the # of likes for
// each attraction icon
int _a1Likes = 0;
int _a2Likes = 0;
int _a3Likes = 0;

class ScreenEight extends StatefulWidget {
  const ScreenEight({Key? key}) : super(key: key);
  @override
  State<ScreenEight> createState() => _EighthScreen();
}
// Screen for Attraction 1 Icon
class _EighthScreen extends State<ScreenEight> {
  void _incrementLikes() {
    setState(() {
      _a1Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Chicago Sky Deck',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image7',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                    },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: Colors.white, width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/ChiSkyDeck.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.white70,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 233 S Wacker Dr, Chicago, IL 60606\n\n'
                'One of the places to visit while in Chicago is\n'
                'the Sky Deck! The Sky Deck can be found on\n'
                'the 103rd floor of the Willis Tower. Vistors\n'
                'can enjoy the view of Chicago while inside a\n'
                'clear observation box on the side of the\n'
                'building. It is a must see place, especially\n'
                'in the evening when all the buildings are\n'
                'lit up. Prices start at \$40 for people 12+\n'
                'and \$30 for children ages 3-11.'
                '',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('Chicago Sky Deck has been liked $_a1Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
          child: const Icon(Icons.favorite_border_sharp, color: Colors.black,),
        backgroundColor: Colors.white
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}

class ScreenNine extends StatefulWidget {
  const ScreenNine({Key? key}) : super(key: key);
  @override
  State<ScreenNine> createState() => _NinthScreen();
}

// Screen for Attraction 2 Icon
class _NinthScreen extends State<ScreenNine> {
  void _incrementLikes() {
    setState(() {
      _a2Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Cloud Gate',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image8',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: Colors.white, width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/CloudGate.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.white70,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 201 E Randolph St, Chicago, IL 60602\n\n'
                'An icon of Chicago, Cloud Gate (aka the Bean)\n'
                'was created in 2006 by sculptor Anish Kapoor\n'
                'and can be found in Millennium Park. It is a\n'
                'must see attraction and is free for everyone!\n'
                'Consider stopping and take a stroll afterwards\n'
                'around Millennium Park, Grant Park, and/or\n'
                'Maggie Daley Park.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            _incrementLikes();
            final snackBar = SnackBar(
                content: Text('Cloud Gate has been liked $_a2Likes times!'),
              duration: const Duration(milliseconds: 1100),);
            ScaffoldMessenger.of(context).showSnackBar(snackBar);
          },
          child: const Icon(Icons.favorite_border_sharp, color: Colors.black,),
          backgroundColor: Colors.white
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}

class ScreenTen extends StatefulWidget {
  const ScreenTen({Key? key}) : super(key: key);
  @override
  State<ScreenTen> createState() => _TenthScreen();
}

// Screen for Attraction 3 Icon
class _TenthScreen extends State<ScreenTen> {
  void _incrementLikes() {
    setState(() {
      _a3Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Navy Pier',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image9',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                    },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: Colors.white, width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/NavyPier.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.white70,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 600 E Grand Ave, Chicago, IL 60611\n\n'
                'Navy Pier is one of Chicago\'s many treasures\n'
                'that can be found in the Streeterville neighbor-\n'
                'hood, right on the lake\'s shoreline. It is\n'
                'home to the Centennial Wheel, which is Navy\n'
                'Pier\'s main attraction. The Pier also houses\n'
                'a carousel, a launch tower, The Shakespeare\n'
                'theater, and many other attractions for guests\n'
                'to enjoy. Ticket Prices for the Ferris Wheel\n'
                'start at \$18.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            _incrementLikes();
            final snackBar = SnackBar(
              content: Text('Navy Pier has been liked $_a3Likes times!'),
              duration: const Duration(milliseconds: 1100),);
            ScaffoldMessenger.of(context).showSnackBar(snackBar);
          },
          child: const Icon(Icons.favorite_border_sharp, color: Colors.black,),
          backgroundColor: Colors.white
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}