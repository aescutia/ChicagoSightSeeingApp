/*
* CS 378 Project 1: Sightseeing App
* By: Alexis Escutia
* NetID: aescut3
* UIN: 679743479
* EatWidgets.dart - Sets up the screens
* for all the icons associated w/
* the EAT Tab
*/

import 'package:flutter/material.dart';

// Global Vars that store the # of likes for
// each restaurant icon
int _r1Likes = 0;
int _r2Likes = 0;
int _r3Likes = 0;


class ScreenTwo extends StatefulWidget {
  const ScreenTwo({Key? key}) : super(key: key);
  @override
  State<ScreenTwo> createState() => _SecondScreen();
}

// Screen for Restaurant 1 Icon
class _SecondScreen extends State<ScreenTwo> {
  void _incrementLikes() {
    setState(() {
      _r1Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Chicago Pizza and Oven\n            Grinder Co.',
          style: TextStyle(
            color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
            //color: Color.fromARGB(0xFF,0xB7,0x1C,0x1C),
            fontSize: 28.0,
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: const Color.fromARGB(0xFF,0xE5,0x39,0x35), width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/ChiOven.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.redAccent,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 2121 N Clark St, Chicago, IL 60614\n\n'
                'Chicago Pizza Oven and Grinder Co. is the\n'
                'place to go for your pizza and sub cravings!\n'
                'Located in the Lincoln Park Neighborhood,\n'
                'this place is known by many for their italian\n'
                'grinder subs, their salad dinners, and their\n'
                'most popular dish: the Pizza Pot pie.',
                style: TextStyle(
                  color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                  fontSize: 15.0,
                ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('Chicago Oven Grinder Co. has been liked $_r1Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Icon(Icons.favorite_border_sharp),
        backgroundColor: const Color.fromARGB(0xFF,0xE5,0x39,0x35),
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}

class ScreenThree extends StatefulWidget {
  const ScreenThree({Key? key}) : super(key: key);
  @override
  State<ScreenThree> createState() => _ThirdScreen();
}

// Screen for Restaurant 2 Icon
class _ThirdScreen extends State<ScreenThree> {
  void _incrementLikes() {
    setState(() {
      _r2Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Frontera Grill',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image2',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: const Color.fromARGB(0xFF,0xE5,0x39,0x35), width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/FronteraGrill.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.redAccent,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    )
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 445 N Clark St, Chicago, IL 60654\n\n'
                'If you\'re looking for a Mexican restaurant in\n'
                'the heart of downtown, then Frontera Grill is\n'
                'the place to go. This restaurant can be found\n'
                'in the River North Neighborhood and is well\n'
                'known for is its authentic Mexican dishes\n'
                'such as Ceviche, Mole, Enchiladas Norteñas,\n'
                'and Flan to name a few.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('Frontera Grill has been liked $_r2Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Icon(Icons.favorite_border_sharp),
        backgroundColor: const Color.fromARGB(0xFF,0xE5,0x39,0x35),
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}

class ScreenFour extends StatefulWidget {
  const ScreenFour({Key? key}) : super(key: key);
  @override
  State<ScreenFour> createState() => _FourthScreen();
}

// Screen for Restaurant 3 Icon
class _FourthScreen extends State<ScreenFour> {
  void _incrementLikes() {
    setState(() {
      _r3Likes++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Kuma\'s Corner',
          style: TextStyle(
              color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
              fontSize: 28.0
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
              image: const DecorationImage(
                  image: AssetImage('Images/ChiSky.jpg'),
                  fit: BoxFit.fill),
              borderRadius: BorderRadius.circular(20.0)
          ),
        ),
        toolbarHeight: 145,
        backgroundColor: Colors.black,
        shadowColor: Colors.white,
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const Padding(padding: EdgeInsets.all(20.0)),
            Hero(
              tag: 'image3',
              child: Container(
                width: 250,
                height: 250,
                child: GestureDetector(
                  onTap: (){
                    Navigator.pop(context);
                  },
                ),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: const Color.fromARGB(0xFF,0xE5,0x39,0x35), width: 5
                  ),
                  image: const DecorationImage(image: AssetImage('Images/KumasCorner.jpeg')),
                  borderRadius: BorderRadius.circular(150),
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.redAccent,
                        offset: Offset(1.0, 1.0),
                        blurRadius: 2.0,
                        spreadRadius: 10.0
                    ),
                  ],
                ),
              ),
            ),
            const Padding(padding: EdgeInsets.all(20.0)),
            const Text('Address: 2900 W Belmont Ave, Chicago, IL 60618\n\n'
                'If you love burgers and love heavy metal, then\n'
                'then look no further than Kuma\'s Corner. This\n'
                'restaurant can be found in many locations, but\n'
                'the original spot can be found in the Avondale\n'
                'neighborhood. Each of their burgers are named\n'
                'after different heavy metal bands such as the\n'
                'Metallica Burger, the Iron Maiden Burger, and\n'
                'the Led Zeppelin Burger to name a few.',
              style: TextStyle(
                color: Color.fromARGB(0xFF,0xFF,0xEC,0xB3),
                fontSize: 15.0,
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _incrementLikes();
          final snackBar = SnackBar(
              content: Text('Kuma\'s Corner has been liked $_r3Likes times!'),
            duration: const Duration(milliseconds: 1100),);
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Icon(Icons.favorite_border_sharp),
        backgroundColor: const Color.fromARGB(0xFF,0xE5,0x39,0x35),
      ),
      backgroundColor: Colors.grey[900],
    );
  }
}